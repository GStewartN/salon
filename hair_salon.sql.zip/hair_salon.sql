-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 16, 2017 at 09:48 PM
-- Server version: 5.6.34-log
-- PHP Version: 7.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hair_salon`
--
CREATE DATABASE IF NOT EXISTS `hair_salon` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `hair_salon`;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `name` varchar(255) DEFAULT NULL,
  `stylist_id` int(11) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`name`, `stylist_id`, `id`) VALUES
('Cher', 0, 34),
('Cher', 0, 35),
('Hoener', 0, 36),
('Hoener', 0, 37),
('Hoener', 0, 38),
('Cher', 0, 39),
('Cher', 0, 40),
('Cher', 0, 41),
('Dennis', 0, 42),
('Sue', 0, 43),
('Cher', 0, 44),
('Cher', 0, 45),
('Dennis', 0, 46),
('Dennis', 0, 47),
('Hoener', 0, 48),
('Hoener', 0, 49),
('Dennis', 0, 50),
('Dennis', 0, 51),
('Dennis', 0, 52),
('Dennis', 0, 53),
('Dennis', 0, 54),
('Dennis', 0, 55),
('Dennis', 0, 56),
('Dennis', 0, 57),
('Dennis', 0, 58),
('Dennis', 0, 59),
('Dennis', 0, 60),
('Dennis', 0, 61),
('Dennis', 0, 62),
('Dennis', 0, 63),
('Dennis', 0, 64),
('Dennis', 0, 65),
('Dennis', 0, 66),
('Dennis', 0, 67),
('Dennis', 0, 68),
('Dennis', 0, 69),
('Dennis', 0, 70),
('Dennis', 0, 71),
('Dennis', 0, 72),
('Dennis', 0, 73),
('Dennis', 0, 74),
('Dennis', 0, 75),
('Dennis', 0, 76),
('Dennis', 0, 77),
('Dennis', 0, 78),
('Dennis', 0, 79),
('Dennis', 0, 80),
('Dennis', 0, 81),
('Dennis', 0, 82),
('Dennis', 0, 83),
('Dennis', 0, 84),
('Dennis', 0, 85),
('Dennis', 0, 86),
('Dennis', 0, 87),
('Dennis', 0, 88),
('Dennis', 0, 89),
('Dennis', 0, 90),
('Dennis', 0, 91),
('Dennis', 0, 92),
('Dennis', 0, 93),
('Dennis', 0, 94),
('Dennis', 0, 95),
('Dennis', 0, 96),
('Dennis', 0, 97),
('Dennis', 0, 98),
('Dennis', 0, 99),
('Dennis', 0, 100),
('Dennis', 0, 101),
('Dennis', 0, 102),
('Dennis', 0, 103),
('Dennis', 0, 104),
('Dennis', 0, 105),
('Dennis', 0, 106),
('Dennis', 0, 107),
('Dennis', 0, 108);

-- --------------------------------------------------------

--
-- Table structure for table `stylists`
--

CREATE TABLE `stylists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stylists`
--
ALTER TABLE `stylists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;
--
-- AUTO_INCREMENT for table `stylists`
--
ALTER TABLE `stylists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
